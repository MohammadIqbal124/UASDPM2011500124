package com.iqbal.uasdpm

class Lecturer (
    var nidn: String,
    var namaDosen: String,
    var jabatan: String,
    var golongan: String,
    var pendidikan: String,
    var keahlian: String,
    var programstudi: String
)